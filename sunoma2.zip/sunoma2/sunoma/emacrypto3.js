
const streamifier = require('streamifier');
const whatsapp = require("wa-multi-session");
const gTTS = require('gtts');
const {
  toDataURL
} = require("qrcode");
const mp3Duration = require('mp3-duration');
const fs = require("fs");
const path = require("path");
const ffmpeg = require('fluent-ffmpeg');
const axios = require('axios');
const OpenAI = require("openai");
const express = require('express');
//

const audioToText = require('./stt.js');

const apiKey = 'sk-proj-PPDWO01c00w0wri7nin0T3BlbkFJUkmWyrO3lutulFyOBkyF';
const openai = new OpenAI({
  apiKey
});

const RAPPORT = false;
let TTS = true;
const NUMBER_PHONE_ADMIN = "@212712756665";
const adminGroupJid ="120363281226537148@g.us";//group log
// "120363128154652876@g.us";


const app = express();
app.use(express.json());
const port = 81;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
//
const STATES = [];
const {
  log,
  info,
  table
} = console;
const states = {
  stores: {},
  config: {},
  tts:true,
  rapport:true,
};
const tickers = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'LTCUSDT', 'DOTUSDT', 'TRXUSDT'];

async function sendToGroup(text) {
  await whatsapp.sendTextMessage({
    sessionId: "admin",
    to: adminGroupJid,
    text,
    isGroup: true,
  });
}

let dataChart = [];
const listPrevCandle = {};

const WhatsappGlitchStart = async () => {
 await fetchCandlestickData();
  log(" loadSessionsFromStorage");
  const save_session = whatsapp.getSession("admin");
  const sessions = whatsapp.getAllSession();
  states.stores = sessions;
  const session = save_session || await whatsapp.startSession("admin");
  log({
    //session
  });
states.session = session;
states.sessions = sessions;
  const assistBot = async (msg = []) => {
    log("sudooo");
    const conversation = msg.message ? msg.message.conversation || msg.message.extendedTextMessage && msg.message.extendedTextMessage.text : null;
    log({
      conversation
    });

    if (conversation) {
      const {
        participant,
        sessionId
      } = msg;
      await whatsapp.sendTextMessage({
        sessionId: msg.sessionId,
        to: adminGroupJid,
        text: " Store: " + sessionId,
        isGroup: true,
        answering: msg,
      });
    }
    return null;
  };

  whatsapp.onMessageReceived(async (msg = []) => {
    const {
      message
    } = msg
    let textInput = message ? message.conversation ||
      message.extendedTextMessage &&
      message.extendedTextMessage.text : "";
    const audioMessage = message && message.audioMessage && message.audioMessage.url || null

    console.log(` ${JSON.stringify()} 
isfrom me: ${msg.key.fromMe} 
isgroup:${msg.key.isGroup} 
text:${textInput} >
audioMessage: ${audioMessage}`);
    ///
    let textOutput = '';
    const callback = async (textOutputAi) => {

      log("cb", textOutputAi);
      await whatsapp.readMessage({
    sessionId: msg.sessionId,
    key: msg.key,
  });
     
      if (states.tts) {
        //const gtts = new gTTS(textOutputAi, "ar");
        const time = Date.now();
        const outputMp3 = "./tts/nn" + time + '.mp3';
        const outputOgg = "./tts/nn" + time + '.ogg';

const {
          buffer,
          diration
        } = await tts(textOutputAi);
    
        const stream = streamifier.createReadStream(buffer);
        
     ffmpeg(stream)
            .toFormat('ogg')
            .audioCodec('libopus')
            .on('end', async () => {
            	await whatsapp.sendTyping({
        sessionId: msg.sessionId,
        to: msg.key.remoteJid,
        diration: diration*900
      });
            	await sleep(diration*800);
              const send = await whatsapp.sendVoiceNote({
                sessionId: msg.sessionId,
                to: msg.key.remoteJid,
           //     isGroup: true,
                answering: msg,
                media: outputOgg,
              });

              await sleep(10000);
              await whatsapp.sendTextMessage({
                sessionId: msg.sessionId,
                to: msg.key.remoteJid,
           //     isGroup: true,
                answering: msg,
                text:textOutputAi,
                
              });
           await sleep(1000);   
      //  if(states.resText)
      if(states.rapport)
      whatsapp.sendTextMessage({
         //       sessionId: msg.sessionId,
         sessionId: "admin",
         to: adminGroupJid,
     //  to: msg.key.remoteJid,
                text: `Input:
${textOutput}
--
textOutputAi:
${textOutputAi}
`,
               isGroup: true,
                answering: msg,
              });
            })
            .on('error', (err) => {
              console.error('Error converting audio:', err);
            })
            .save(outputOgg);
        
      }
      if (states.rapport)
        whatsapp.sendTextMessage({
          sessionId: "admin",
          to: adminGroupJid,
          text: inspectMsg(msg),
          isGroup: true,
          answering: msg,
        });
    };

    //
    if (audioMessage && !msg.key.fromMe) {
      try {

         textOutput = await audioToText(msg);
        log("transcri^top,=", {
          textOutput
        })
        if (textOutput)
          getGpt({
            store: msg.sessionId,
            prompt: states.stores[msg.sessionId] ? states.stores[msg.sessionId].prompt : null,
            text: textOutput,
          }, callback);

        //console.log('Transcription:', text);
      } catch (error) {
        console.error('Failed to transcribe audio:', error);
      }

    }


    if (textInput && textInput.includes(NUMBER_PHONE_ADMIN)) {

      textInput = textInput.replace(NUMBER_PHONE_ADMIN, "")
      getGpt({
        store: msg.sessionId,
        prompt: states.stores[msg.sessionId] ? states.stores[msg.sessionId].prompt : null,
        text: textInput,
      }, callback);

    }

  })
};
WhatsappGlitchStart();

function getGpt({
  store,
  text,
  prompt
}, callback) {
  log("stargpt fn");
if(states.inactiveGpt) return;
  const listPrevCandleStringify = JSON.stringify(listPrevCandle);

  const data = JSON.stringify({
    text,
    prompt,
    system: (states.system || SYSTEM_PROMPT)+ listPrevCandleStringify
  });
  log({data});

  const config = {
    method: 'post',
    maxBodyLength: Infinity,
    url: 'https://mojoland.deno.dev/api/gptino',
    headers: {
      'Content-Type': 'application/json'
    },
    data
  };

  axios.request(config)
    .then((response) => {
      console.log(JSON.stringify(response.data));
      const text = response.data.text || "not text in data return ";
      callback(text);
    })
    .catch((error) => {
      console.log(error);
    });
}

async function fetchCandlestickData() {
  try {
    const interval = states.interval || '4h';
    const currentTime = Math.floor(Date.now() / 1000);
    const fourHoursAgo = currentTime - (4 * 60 * 60);

    const requests = tickers.map(ticker => {
      return axios.get(`https://api.binance.com/api/v3/klines?symbol=${ticker}&interval=${interval}&startTime=${(fourHoursAgo - (4 * 60 * 60)) * 1000}&endTime=${fourHoursAgo * 1000}`);
    });

    const responses = await Promise.all(requests);
    const candlestickData = responses.map(response => response.data);
    processCandlestickData(candlestickData);
  } catch (error) {
    console.error('Error occurred while fetching candlestick data:', error);
  }
}

function processCandlestickData(data) {
  data.forEach(async (candlestick, index) => {
    const symbol = tickers[index];
    console.log('Candlestick data for currency:', tickers[index]);
    console.log('------------------------');
    let low, high, close, open, time;
    candlestick.forEach(candle => {
      low = candle[3];
      high = candle[2];
      close = candle[4];
      open = candle[1];
      time = new Date(candle[0]).toLocaleString();
    });

    const kline = {
      symbol,
      low,
      high,
      close,
      open,
      time
    };
    const goldLine = ((+close) + (+open) + (+high)) / 3;
    listPrevCandle[symbol] = kline;
    listPrevCandle[symbol].goldLine = goldLine
 console.log(listPrevCandle[symbol])
 });
}

async function tts(input) {
  if (!input) return false;

  const time = Date.now();
  const speechFile = path.resolve(`./tts/speech-${time}.mp3`);

  const mp3 = await openai.audio.speech.create({
    model: "tts-1",
    voice://"shimmer", 
"alloy",
    input,
  });

  console.log(speechFile);
  const buffer = Buffer.from(await mp3.arrayBuffer());

  try {
    const duration = await mp3Duration(buffer);
    console.log({
      duration
    });
    return {
      buffer,
      duration: duration 
    };
  } catch (error) {
    console.error('Error getting MP3 duration:', error);
    return {
      buffer,
      duration: 5
    };
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function isExistText(text = "", value = "") {
  return text.replaceAll(value, "")
}
//
function inspectMsg(msg={}) {
    // Extracting important variables with optional chaining
    const importantData = {
        remoteJid: msg?.key?.remoteJid,
        participant: msg?.key?.participant,
        pushName: msg?.pushName,
        messageTimestamp: msg?.messageTimestamp,
        audioMessage: msg?.message?.audioMessage ? {
            url: msg.message.audioMessage.url,
            mimetype: msg.message.audioMessage.mimetype,
            fileLength: msg.message.audioMessage.fileLength,
            seconds: msg.message.audioMessage.seconds,
            ptt: msg.message.audioMessage.ptt
        } : null
    };

    return JSON.stringify(importantData);
}
//
app.get('/send', async (req, res, next) => {
  try {
    const { number = '', text = 'سلام', isgroup = 'false' } = req.query;

    if (!number) {
      return res.status(400).json({
        error: "رقم الهاتف مطلوب!"
      });
    }

    const isGroup = isgroup.toLowerCase() === 'true';
   // const encodedText = encodeURIComponent(text);

    const data = await whatsapp.sendTextMessage({
      sessionId: "admin",
      to: number + "@s.whatsapp.net",
      text,
      isGroup: isGroup,
    });

    if (data) {
      res.status(200).json({
        data
      });
    } else {
      throw new Error("فشل إرسال الرسالة");
    }
  } catch (error) {
    next(error);
  }
});
//
const SYSTEM_PROMPT = `
تقمص دور متدربة عند المهندس ابراهيم بيدي، وهو يخولك ان تجيبي على هذه التخصصات والتي تدربتي عليها وتعلمتها من ابراهيم بيدي، التخصصات البرمجة و والكريبتو والذكاء الإصطناعي  

أجيبي بلباقة و كل دقة و ابداع اضيفي ايقونات ان امكن، حاول ان لا تتعدى في رد على 7 اسطر بالكثير اختصر ما امكن لك اختصاره وشكرا
اذا كانت هناك ارقام في ردك فحولها الى حروف منطوقة و ليس ارقام وشكرا مرة اخرة 
اذا كانت هناك استفسارات شخصية فقولي يمكنك الاتصال ومراسلته مباشرة على هذا الرقم 
0648188181

`;

//
const SYSTEM_PROMPT22 = `إسمك روز وانت مرشدة قانونية معتمدة في المملكة العربية السعودية لدليل ممارسات الموارد البشرية،
اجيبي العميل انطلاقا من هذه البيانات
___

النسخة الأولى
معتمدة بموجب القرار الإداري رقم (423) وتاريخ 20/06/1445ه الموافق 02/01/2024م

*الفصل الأول: أحكام عامة

*الهدف:
تنظيم وضبط سير العمليات ضمن الموارد البشرية في المركز السعودي للأعمال الاقتصادية، وتوضيح العلاقة والحقوق والواجبات بين المركز وموظفيه.
*النظام المتبع:
اللائحة الإدارية المعتمدة بموجب برقية وزارة المالية رقم (7740) وتاريخ 04/09/1443ه،  ووفق أنظمة العمل السعودية واللوائح التنفيذية ونظام التأمينات الاجتماعية، والأنظمة الداخلية.
*نطاق الممارسات:
 تسري أحكام هذا الدليل على جميع منسوبي المركز السعودي للأعمال والمعارين للمركز، وعلى جميع التصرفات والتعاملات الإدارية للمركز.
*التعريفات:
توضيح لمعاني المصطلحات الرئيسية مثل: المركز، المجلس، المسؤول الأول، صاحب الصلاحية، العامل، عقد العمل، الأجر الأساسي، الأجر الثابت، الأجر الفعلي، التكليف، النقل، الإعارة، الاستعارة، الترقية، العمل الإضافي، الشهر، النظام، المخالفات والجزاءات، مصفوفة الصلاحيات، المرافقون، نظام المنافسات، اللائحة التنفيذية، لائحة تنظيم تعارض المصالح، الموظفين، الأقارب، المتعامل، الإفصاح، التبليغ، المصلحة الخاصة، تعارض المصالح، الجهة المختصة، الهدايا المقبولة، الرشوة، الضيافة، المشاركة المجتمعية.

**الفصل الثاني: التزامات الطرفين**

* **التزامات المركز:** معاملة العامل بشكل لائق، توفير بيئة عمل آمنة ومناسبة، دفع أجر العامل بالريال السعودي، دفع أجر العامل عن المدة التي لم يؤد فيها العمل، الاحتفاظ بسجل للعامل، احترام مدة إخطار العامل قبل إنهاء عقد العمل.
* **التزامات العامل:** مراعاة تعاليم الدين الإسلامي والأنظمة والأعراف، الالتزام بجميع اللوائح والتنظيمات، المحافظة على مواعيد العمل، إنجاز عمله على الوجه المطلوب، تجنب كل ما يخل بشرف الوظيفة والكرامة، الالتزام بحسن السيرة والسلوك، العناية والمحافظة على ممتلكات المركز، تقديم العون أو المساعدة في الحالات الطارئة، التقيد بالإرشادات الصحية، المحافظة على ما يحمله من معلومات، عدم إفشاء أي معلومة سرية، عدم الإدلاء أو الإفصاح بأي تصريح لوسائل الإعلام، عدم ممارسة أي عمل آخر خارج نطاق عمله، الامتناع عن إساءة استعمال الصلاحيات الوظيفية، إخطار المركز بكل تغيير يطرأ على حالته الاجتماعية، احترام مدة إخطار المركز قبل إنهاء عقد العمل، غض البصر واحترام المساحة الشخصية للجنس الآخر، الالتزام بالزي الرسمي.

**الفصل الثالث: التطوير التنظيمي وتخطيط الموارد البشرية**

* **الهيكل التنظيمي:** تقوم إدارة الموارد البشرية بإعداد الهيكل التنظيمي، ويتم مراجعة الهيكل التنظيمي للمركز على أساس دوري.
* **الأوصاف الوظيفية:** تقوم الموارد البشرية بالتعاون مع مدراء الإدارات بإعداد وصف وظيفي لكل وظيفة، ويتم مراجعة الوصف الوظيفي على أساس دوري.
* **تصنيف الدرجات الوظيفية وتقييم الوظائف:** يتم تصنيف العاملين بحسب فئاتهم المهنية، بالاسترشاد بدليل التصنيف والتوصيف المهني السعودي.
* **سلم الدرجات الوظيفية:** جدول يوضح المستويات الوظيفية من 1 إلى 15.

**الفصل الرابع: التوظيف**

* **استقطاب الكفاءات:** الجدارة والكفاءة هي الأساس في اختيار المرشحين، ويجب مراعاة شروط محددة عند شغل الوظائف بالكوادر البشرية.
* **استقطاب داخلي:** للمركز الإعلان عن جميع الوظائف داخلياً أولاً، وإعطاء موظفيه الأولوية.
* **استقطاب خارجي:** في حال لم يتقدم أي من العاملين للترشح على الوظيفة، فللمركز حق استقطاب من يراه مناسباً والإعلان عن الوظائف خارجياً.
* **الإعارة:** يجوز إعارة العامل -بعد موافقته- للعمل لدى أي جهة عامة أو خاصة، وتكون إعارته بقرار من المسؤول الأول أو المجلس.

**الفصل الخامس: العرض الوظيفي والتعاقد**

* **العرض الوظيفي:** يعد المركز العرض الوظيفي بناءً على هيكل الدرجات الوظيفية، وسلم الرواتب الوظيفي المعتمد.
* **عقد العمل:** يُوظف المرشح بموجب عقد العمل يحرر من نسختين باللغة العربية.
* **فترة التجربة:** يخضع العامل للتجربة مدة (٩٠) يوماً ابتداءً من تاريخ مباشرته للعمل، ويجوز باتفاق الطرفين تمديد مدة التجربة على أن لا تزيد في مجموعها على (١٨٠) يوماً.

**الفصل السادس: الأجور والبدلات والمكافآت والرسوم**

* **الأجر الشهري:** يحتسب للعامل أجره ومستحقاته من تاريخ مباشرته للعمل، ويدفع أجره شهرياً بحسب ما يتفق عليه في عقد العمل، ووفق سلم الرواتب الوظيفي المعتمد.
* **بدل السكن:** يمنح العامل بحسب درجته الوظيفية، بدل سكن بمبلغ مقطوع ثابت.
* **بدل النقل:** يمنح العامل بحسب درجته الوظيفية، بدل مواصلات بمبلغ مقطوع ثابت.
* **بدل الانتداب:** يمنح العامل بدل انتداب بحسب درجته الوظيفية.
* **بدل اتصال:** يجوز منح العامل بدل اتصال لا يتجاوز 500 ريال سعودي شهرياً.
* **بدل التعليم:** يمنح العامل بدل تعليم أبناء للمساهمة في تغطية تكاليف التعليم المدرسي لأبنائه في حال كانوا في مدارس خاصة.

**الفصول المتبقية:**

* **الفصل السابع:** إدارة الأداء وتقييم مستوى الأداء الوظيفي والمكافآت والعلاوات.
* **الفصل الثامن:** التكليف والنقل.
* **الفصل التاسع:** التدريب والابتعاث.
* **الفصل العاشر:** الإركاب والانتداب.
* **الفصل الحادي عشر:** شروط العمل وظروفه.
* **الفصل الثاني عشر:** الإجازات.
* **الفصل الثالث عشر:** الرعاية الصحية والوقاية والسلامة المهنية.
* **الفصل الرابع عشر:** انتهاء الخدمة ومكافأة نهاية الخدمة.
* **الفصل الخامس عشر:** المخالفات والجزاءات.
* **الفصل السادس عشر:** التظلم.
* **الفصل السابع عشر:** سياسة الحد من التحرش والعنصرية.
* **الفصل الثامن عشر:** سياسة تعارض المصالح.


`;

