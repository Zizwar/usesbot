const whatsapp = require("wa-multi-session");

const {
  toDataURL
} = require("qrcode");

//const qrcode = require('qrcode-terminal');
const axios = require('axios');
const express = require('express');
//
const app = express();
app.use(express.json());
const port = 82;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
//
const {
  log,
  info,
  table
} = console;

const states = {
  stores: {},
  config: {}
}
//const adminGroupJid = "120363128154652876@g.us";
const adminGroupJid = "120363281226537148@g.us"; //group log

async function sendToGroup(text, props={}) {
  const {
  answering = null,
  isGroup = true,
  sessionId = "admin",
  to = adminGroupJid
} = props;
  const options = {
    isGroup,
    sessionId,
    to,
    text
  };

  if (answering) {
    options.answering = answering;
  }

  return await whatsapp.sendTextMessage(options);
}
app.get('/all', async (req, res, next) => {
  try {
    const stores = whatsapp.getAllSession();
    sendToGroup("all stores: " + JSON.stringify(stores))

    res.status(200).json({
      stores
    });
  } catch (error) {
    next(error);
  }

})
app.get('/delete/:store', async (req, res, next) => {
  try {
    const {
      store
    } = req.params || "mujeeb";
    whatsapp.deleteSession(store);
    res
      .status(200)
      .send("Success Deleted " + store)
    if (states.stores[store])
      delete states.stores[store]
    sendToGroup("❌deleted store #" + store)
  } catch (error) {
    next(error);
  }

})
const answers = [];
app.post('/send-message', async (req, res, next) => {
  /*
const message = {
  text: "This is a template message",
  templateButtons: [
    { index: 1, urlButton: { displayText: "Visit website", url: "https://google.com" } },
    { index: 2, callButton: { displayText: "Call us", phoneNumber: "+1234567890" } },
  ],
};
//
await whatsapp.sendTextMessage({
        sessionId: "admin",
      to: adminGroupJid,
        text:message,
        isGroup: true,
      });
      */
  const {
    text,
    symbol,
    method
  } = req.body;
  const answering = method === "get" ? answers[symbol] : null;
  ///
  const reswats = await sendToGroup(
    text, {
      answering,
    });
  if (method === "set")
    answers[symbol] = reswats;
  res.json({
    answering: reswats
  })
  log("whtsrep", reswats)
  return;

})


app.get('/create/:store', async (req, res, next) => {
 // return;
  try {
    const {
      store
    } = req.params || "mujeeb";
    log('creaet,', store)

    whatsapp.onQRUpdated(async (data) => {

      log('onqrcode,', data)
      if (!states.stores[store]) {
        const qr = await toDataURL(data.qr);
        if (data.sessionId == store) {
          res.send(`<img width="50%" src="${qr}" alt="QR Code" />`);
        } else {
          res.status(200).json({
            qr: data.qr,
          });
        }
      }
    });
    await whatsapp.startSession(store, {
      printQR: true
    });
    sendToGroup("store created 🥳 #" + store)
  } catch (error) {
    next(error);
    sendToGroup("error created store : " + store)
  }
})

////
const tickers = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'LTCUSDT', 'DOTUSDT', 'TRXUSDT'];

let dataChart = []
const listPrevCandle = {}
const WhatsappGlitchStart = async () => {


  //whatsapp.loadSessionsFromStorage()
  log(" loadSessionsFromStorage")
  const save_session = whatsapp.getSession("admin");
  const sessions = whatsapp.getAllSession()
  states.stores = sessions;
  // returning session data
  //log({save_session})
  // create session with ID : mysessionid

  const session = save_session || await whatsapp.startSession("admin");
  log({
    session
  })
  // Then, scan QR on terminal
  //const sessions = whatsapp.getAllSession();
  //log({  sessions  })
  // returning all session ID that has been created
  //qrcode.generate(qr, {small: true});
  //
  const assistBot = async (msg = []) => {
    log("sudooo")
    const conversation = msg.message ? msg.message.conversation || msg.message.extendedTextMessage && msg.message.extendedTextMessage.text : null
    //    if (!conversation.includes("$sudo")) return null;
    log({
      conversation
    })


    if (conversation) {
      const {
        participant,
        sessionId
      } = msg;

      await sendToGroup(" Store: " + sessionId, {
        answering: msg
      })
    }
    return null;
  }

  whatsapp.onMessageReceived((msg) => {

    ///

    // log('====', JSON.stringify(msg.message.extendedTextMessage.text))
    /*  if (msg.sessionId === "admin") {
        assistBot(msg);
        return
      }
      */

    //
    
    const callback = async (text) => {
      log("cb", text)
      await sleep(5000);
      await whatsapp.sendTextMessage({
        sessionId: msg.sessionId,
        to: msg.key.remoteJid,
        text,
        //  isGroup: true,
        answering: msg, // for quoting message
      });
      // return;
      //log to admin
      const logz = (`
Session: ${msg.sessionId}
from: ${msg.key.remoteJid}
isfrom me: ${msg.key.fromMe} 
isgroup:${msg.key.isGroup} 

textOutputIa:${text} >
`);
      log(logz)
      await sleep(5000)
      sendToGroup(logz, {
        answering: msg
      });
    }
    // if (msg.message && msg.message.conversation.includes("$") || msg.message && msg.message.extendedTextMessage && msg.message.extendedTextMessage.text.includes("$"))
    const {
      message
    } = msg
    const textIn = message ? message.conversation ||
      message.extendedTextMessage &&
      message.extendedTextMessage.text : "";
  
    if (!msg.key.fromMe)
      getGpt({
        store: msg.sessionId,
        text: textIn
      }, callback)
  });
  /*
  whatsapp.onConnected((sessionId) => {
    //  states.stores[sessionId] && (states.stores[sessionId].exist = true)
    console.log("session connected :" + sessionId);

  });
  */
}
WhatsappGlitchStart();

//
function getGpt({
  store,
  text,
  prompt
}, callback) {
  log("stargpt fn");
  if (states.inactiveGpt) return;

  const data = JSON.stringify({
    text,
    prompt,
    system: (states.system || SYSTEM_PROMPT)
  });
  log({
    data
  });

  const config = {
    method: 'post',
    maxBodyLength: Infinity,
    url: 'https://mojoland.deno.dev/api/gptino',
    headers: {
      'Content-Type': 'application/json'
    },
    data
  };

  axios.request(config)
    .then((response) => {
      console.log(JSON.stringify(response.data));
      const text = response.data.text || "لا يوجد نص في البيانات المرتجعة";

      callback(text);
    })
    .catch((error) => {
      console.log(error);
    });
}

//
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

//
const SYSTEM_PROMPT = `اريدك ان تستخرج من هذا النص  العنوان وتركبه في title وان لم يكن فإستنبطه من النص بشكل عام، 
واستخرج كذالك كلمات الاغنية وان لم تكن وكان يطلب منك كتابتها فأبدع في كلماتك وفق الطلب وركبها في prompt 
العنوان 
استخرج كذالك ستيل الاغنية وركبها في tag وان لم تكن فكتبها من عندك بالانجليزية حسب النص الذي تراه و حسب المطلوب منك
 رد علي دائيما بجيزن .
مثال على طلب: 
اريد اغنية بستيل اطفال وهذه كلماتها [Intro]\nسأسافرُ عبرَ الارض\nباحثا في كلِ مكان \n عن روكيموني اداةِ \nالسلام\nقوةُ لا تهان\nروكيموني سأجمعها الان\nفلتساندني\nبقوتك ساعدني\nآه لحلمنا الوحيد نحو عالمِ جديد
انت سترد بملف جيزن
please remember return  json like this:
{
  "prompt": "[Intro]\nسأسافرُ عبرَ الارض\nباحثا في كلِ مكان \n عن روكيموني اداةِ \nالسلام\nقوةُ لا تهان\nروكيموني سأجمعها الان\nفلتساندني\nبقوتك ساعدني\nآه لحلمنا الوحيد نحو عالمِ جديد
....[outro]",
  "tags": "dreamy kids music",
  "title": "روكيموني",
}`;
const SYSTEM_PROMPTz = `إسمك روز وانت مرشدة قانونية معتمدة في المملكة العربية السعودية لدليل ممارسات الموارد البشرية،
اجيبي العميل انطلاقا من هذه البيانات
___

النسخة الأولى
معتمدة بموجب القرار الإداري رقم (423) وتاريخ 20/06/1445ه الموافق 02/01/2024م

*الفصل الأول: أحكام عامة

*الهدف:
تنظيم وضبط سير العمليات ضمن الموارد البشرية في المركز السعودي للأعمال الاقتصادية، وتوضيح العلاقة والحقوق والواجبات بين المركز وموظفيه.
*النظام المتبع:
اللائحة الإدارية المعتمدة بموجب برقية وزارة المالية رقم (7740) وتاريخ 04/09/1443ه،  ووفق أنظمة العمل السعودية واللوائح التنفيذية ونظام التأمينات الاجتماعية، والأنظمة الداخلية.
*نطاق الممارسات:
 تسري أحكام هذا الدليل على جميع منسوبي المركز السعودي للأعمال والمعارين للمركز، وعلى جميع التصرفات والتعاملات الإدارية للمركز.
*التعريفات:
توضيح لمعاني المصطلحات الرئيسية مثل: المركز، المجلس، المسؤول الأول، صاحب الصلاحية، العامل، عقد العمل، الأجر الأساسي، الأجر الثابت، الأجر الفعلي، التكليف، النقل، الإعارة، الاستعارة، الترقية، العمل الإضافي، الشهر، النظام، المخالفات والجزاءات، مصفوفة الصلاحيات، المرافقون، نظام المنافسات، اللائحة التنفيذية، لائحة تنظيم تعارض المصالح، الموظفين، الأقارب، المتعامل، الإفصاح، التبليغ، المصلحة الخاصة، تعارض المصالح، الجهة المختصة، الهدايا المقبولة، الرشوة، الضيافة، المشاركة المجتمعية.

**الفصل الثاني: التزامات الطرفين**

* **التزامات المركز:** معاملة العامل بشكل لائق، توفير بيئة عمل آمنة ومناسبة، دفع أجر العامل بالريال السعودي، دفع أجر العامل عن المدة التي لم يؤد فيها العمل، الاحتفاظ بسجل للعامل، احترام مدة إخطار العامل قبل إنهاء عقد العمل.
* **التزامات العامل:** مراعاة تعاليم الدين الإسلامي والأنظمة والأعراف، الالتزام بجميع اللوائح والتنظيمات، المحافظة على مواعيد العمل، إنجاز عمله على الوجه المطلوب، تجنب كل ما يخل بشرف الوظيفة والكرامة، الالتزام بحسن السيرة والسلوك، العناية والمحافظة على ممتلكات المركز، تقديم العون أو المساعدة في الحالات الطارئة، التقيد بالإرشادات الصحية، المحافظة على ما يحمله من معلومات، عدم إفشاء أي معلومة سرية، عدم الإدلاء أو الإفصاح بأي تصريح لوسائل الإعلام، عدم ممارسة أي عمل آخر خارج نطاق عمله، الامتناع عن إساءة استعمال الصلاحيات الوظيفية، إخطار المركز بكل تغيير يطرأ على حالته الاجتماعية، احترام مدة إخطار المركز قبل إنهاء عقد العمل، غض البصر واحترام المساحة الشخصية للجنس الآخر، الالتزام بالزي الرسمي.

**الفصل الثالث: التطوير التنظيمي وتخطيط الموارد البشرية**

* **الهيكل التنظيمي:** تقوم إدارة الموارد البشرية بإعداد الهيكل التنظيمي، ويتم مراجعة الهيكل التنظيمي للمركز على أساس دوري.
* **الأوصاف الوظيفية:** تقوم الموارد البشرية بالتعاون مع مدراء الإدارات بإعداد وصف وظيفي لكل وظيفة، ويتم مراجعة الوصف الوظيفي على أساس دوري.
* **تصنيف الدرجات الوظيفية وتقييم الوظائف:** يتم تصنيف العاملين بحسب فئاتهم المهنية، بالاسترشاد بدليل التصنيف والتوصيف المهني السعودي.
* **سلم الدرجات الوظيفية:** جدول يوضح المستويات الوظيفية من 1 إلى 15.

**الفصل الرابع: التوظيف**

* **استقطاب الكفاءات:** الجدارة والكفاءة هي الأساس في اختيار المرشحين، ويجب مراعاة شروط محددة عند شغل الوظائف بالكوادر البشرية.
* **استقطاب داخلي:** للمركز الإعلان عن جميع الوظائف داخلياً أولاً، وإعطاء موظفيه الأولوية.
* **استقطاب خارجي:** في حال لم يتقدم أي من العاملين للترشح على الوظيفة، فللمركز حق استقطاب من يراه مناسباً والإعلان عن الوظائف خارجياً.
* **الإعارة:** يجوز إعارة العامل -بعد موافقته- للعمل لدى أي جهة عامة أو خاصة، وتكون إعارته بقرار من المسؤول الأول أو المجلس.

**الفصل الخامس: العرض الوظيفي والتعاقد**

* **العرض الوظيفي:** يعد المركز العرض الوظيفي بناءً على هيكل الدرجات الوظيفية، وسلم الرواتب الوظيفي المعتمد.
* **عقد العمل:** يُوظف المرشح بموجب عقد العمل يحرر من نسختين باللغة العربية.
* **فترة التجربة:** يخضع العامل للتجربة مدة (٩٠) يوماً ابتداءً من تاريخ مباشرته للعمل، ويجوز باتفاق الطرفين تمديد مدة التجربة على أن لا تزيد في مجموعها على (١٨٠) يوماً.

**الفصل السادس: الأجور والبدلات والمكافآت والرسوم**

* **الأجر الشهري:** يحتسب للعامل أجره ومستحقاته من تاريخ مباشرته للعمل، ويدفع أجره شهرياً بحسب ما يتفق عليه في عقد العمل، ووفق سلم الرواتب الوظيفي المعتمد.
* **بدل السكن:** يمنح العامل بحسب درجته الوظيفية، بدل سكن بمبلغ مقطوع ثابت.
* **بدل النقل:** يمنح العامل بحسب درجته الوظيفية، بدل مواصلات بمبلغ مقطوع ثابت.
* **بدل الانتداب:** يمنح العامل بدل انتداب بحسب درجته الوظيفية.
* **بدل اتصال:** يجوز منح العامل بدل اتصال لا يتجاوز 500 ريال سعودي شهرياً.
* **بدل التعليم:** يمنح العامل بدل تعليم أبناء للمساهمة في تغطية تكاليف التعليم المدرسي لأبنائه في حال كانوا في مدارس خاصة.

**الفصول المتبقية:**

* **الفصل السابع:** إدارة الأداء وتقييم مستوى الأداء الوظيفي والمكافآت والعلاوات.
* **الفصل الثامن:** التكليف والنقل.
* **الفصل التاسع:** التدريب والابتعاث.
* **الفصل العاشر:** الإركاب والانتداب.
* **الفصل الحادي عشر:** شروط العمل وظروفه.
* **الفصل الثاني عشر:** الإجازات.
* **الفصل الثالث عشر:** الرعاية الصحية والوقاية والسلامة المهنية.
* **الفصل الرابع عشر:** انتهاء الخدمة ومكافأة نهاية الخدمة.
* **الفصل الخامس عشر:** المخالفات والجزاءات.
* **الفصل السادس عشر:** التظلم.
* **الفصل السابع عشر:** سياسة الحد من التحرش والعنصرية.
* **الفصل الثامن عشر:** سياسة تعارض المصالح.


`;